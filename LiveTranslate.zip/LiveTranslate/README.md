# Subtítulos en vivo, versión 3 (Android)

Captura el audio del móvil, lo transcribe con Vosk y muestra la traducción como subtítulos flotantes.

## Novedades de la v3
- Diseño oscuro con tarjetas, botones con degradado y icono propio (con versión monocromática para Android 13+).

## Novedades de la v2
- Pantalla de ajustes: tamaño de letra, color, opacidad del fondo y posición inicial, con vista previa.
- Subtítulos arrastrables con el dedo y botón "Detener" en la propia ventana flotante.
- Opción de mostrar también el texto original.
- Idioma de origen: inglés, español, francés, alemán, italiano, portugués y ruso.
- Idioma de destino: los anteriores más japonés, chino, coreano, árabe y hindi.
- Los modelos de voz se descargan solos desde la app la primera vez que eliges un idioma (unos 40 MB cada uno).
- Traducción más exacta: las frases completas se traducen siempre, y los fragmentos a medias solo cuando ya tienen 5 o más palabras.

## Compilar con GitHub (sin PC)
Sube este zip al repositorio con el mismo nombre (LiveTranslate.zip) y ejecuta de nuevo el flujo "Crear APK". El flujo anterior sigue funcionando; el APK pesará unos 40 MB de más porque aún mete el modelo inglés, que la v2 ya no usa. Si quieres evitarlo, borra del flujo las líneas desde "curl" hasta "rm -rf".

## Limitaciones
- Netflix, Disney+ y otras apps bloquean la captura de audio.
- Retraso típico de 1 a 3 segundos.
- Los modelos pequeños de Vosk fallan con acentos fuertes o música alta.
