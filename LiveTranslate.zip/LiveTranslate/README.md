# Subtítulos EN→ES en tiempo real (Android)

Captura el audio que suena en el móvil, lo transcribe en inglés (Vosk, sin conexión) y muestra la traducción al español (ML Kit) como subtítulos flotantes.

## Pasos para compilarlo

1. **Descarga el modelo de voz**: `vosk-model-small-en-us-0.15` desde https://alphacephei.com/vosk/models (unos 40 MB).
2. Descomprímelo y copia **todo su contenido** (carpetas `am`, `conf`, `graph`, `ivector`, y el archivo `README`) dentro de `app/src/main/assets/model-en-us/`.
3. En esa misma carpeta crea un archivo vacío llamado `uuid` (con cualquier texto dentro, por ejemplo `1`). Vosk lo usa para saber cuándo recopiar el modelo.
4. Abre la carpeta `LiveTranslate` con **Android Studio** (Koala o posterior) y deja que sincronice Gradle.
5. Conecta tu móvil con depuración USB y pulsa **Run**. Para un APK suelto: Build → Build APK(s).

## Uso

1. Abre la app y pulsa **Iniciar**.
2. Concede superposición, micrófono y notificaciones.
3. La primera vez descarga el modelo de traducción (necesita internet, unos 30 MB). Después funciona sin conexión.
4. Acepta la captura de audio y abre tu vídeo. Los subtítulos aparecen abajo.
5. Para parar, vuelve a la app y pulsa **Detener**.

## Limitaciones

- Netflix, Disney+ y otras apps bloquean la captura de audio: no se oirá nada.
- Retraso típico de 1 a 3 segundos.
- El modelo pequeño de Vosk falla con acentos fuertes o música alta. Si quieres más precisión, usa `vosk-model-en-us-0.22-lgraph` (unos 130 MB).
- Android 10 o superior.
