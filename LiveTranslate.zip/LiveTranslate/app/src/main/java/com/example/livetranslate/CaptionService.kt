package com.example.livetranslate

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.IntentCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService

class CaptionService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "captions"
        private const val SAMPLE_RATE = 16000
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var translator: Translator? = null
    private var overlay: TextView? = null
    private var worker: Thread? = null

    @Volatile private var running = false
    private val clearRunnable = Runnable { overlay?.text = "" }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            // Obligatorio en Android 14+ antes de usar la proyección
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, main)
        }

        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build()
        )

        createOverlay()
        show("Cargando reconocimiento de voz...")

        StorageService.unpack(
            this, "model-en-us", "model",
            { m ->
                model = m
                recognizer = Recognizer(m, SAMPLE_RATE.toFloat())
                show("Listo. Reproduce un vídeo.")
                startCapture()
            },
            { e -> show("Error con el modelo: ${e.message}") }
        )
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Subtítulos", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Subtítulos EN→ES activos")
            .setContentText("Traduciendo el audio del dispositivo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun createOverlay() {
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(190, 0, 0, 0))
            textSize = 18f
            gravity = Gravity.CENTER
            val p = (10 * dp).toInt()
            setPadding(p, p, p, p)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            y = (96 * dp).toInt()
        }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, lp)
        overlay = tv
    }

    private fun show(text: String) {
        main.post {
            overlay?.text = text
            main.removeCallbacks(clearRunnable)
            main.postDelayed(clearRunnable, 5000)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startCapture() {
        val proj = projection ?: return
        val config = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(maxOf(minBuf, 8000) * 2)
            .setAudioPlaybackCaptureConfig(config)
            .build()
        record = rec
        rec.startRecording()
        running = true

        worker = Thread {
            val buf = ShortArray(4000) // 0,25 s de audio
            var lastPartial = ""
            var lastPartialTime = 0L
            val rcg = recognizer ?: return@Thread
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (rcg.acceptWaveForm(buf, n)) {
                    val text = JSONObject(rcg.result).optString("text")
                    if (text.isNotBlank()) translate(text)
                } else {
                    val partial = JSONObject(rcg.partialResult).optString("partial")
                    val now = System.currentTimeMillis()
                    // Traducir parciales con un límite para no saturar
                    if (partial.isNotBlank() && partial != lastPartial && now - lastPartialTime > 800) {
                        lastPartial = partial
                        lastPartialTime = now
                        translate(partial)
                    }
                }
            }
        }.also { it.start() }
    }

    private fun translate(text: String) {
        translator?.translate(text)
            ?.addOnSuccessListener { show(it) }
    }

    override fun onDestroy() {
        running = false
        worker?.join(500)
        record?.run { runCatching { stop() }; release() }
        recognizer?.close()
        model?.close()
        translator?.close()
        projection?.stop()
        main.removeCallbacksAndMessages(null)
        overlay?.let { runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } }
        super.onDestroy()
    }
}
