package com.example.livetranslate

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.IntentCompat
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

class CaptionService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "captions"
        private const val SAMPLE_RATE = 16000
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var translator: Translator? = null
    private var box: LinearLayout? = null
    private var tvOrig: TextView? = null
    private var tvTrans: TextView? = null
    private var worker: Thread? = null
    @Volatile private var running = false
    @Volatile private var destroyed = false
    private val clearRunnable = Runnable { tvOrig?.text = ""; tvTrans?.text = "" }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        startAsForeground()
        val prefs = Config.prefs(this)
        val src = prefs.getString("src", "en")!!
        val dst = prefs.getString("dst", "es")!!

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, main)
        }
        translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build()
        )
        createOverlay()
        show("Cargando reconocimiento de voz...")

        Thread {
            try {
                val dir = ModelStore.ensure(this, src) { p -> show("Descargando modelo de voz... $p%") }
                val m = Model(dir.absolutePath)
                if (destroyed) { m.close(); return@Thread }
                model = m
                recognizer = Recognizer(m, SAMPLE_RATE.toFloat())
                show("Listo. Reproduce un vídeo.")
                startCapture()
            } catch (e: Exception) {
                show("Error con el modelo de voz: ${e.message}")
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Subtítulos", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Subtítulos activos")
            .setContentText("Traduciendo el audio del dispositivo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun createOverlay() {
        val prefs = Config.prefs(this)
        val dp = resources.displayMetrics.density
        val size = prefs.getInt("size", 18).toFloat()
        val pad = (10 * dp).toInt()

        val orig = TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = size * 0.7f; gravity = Gravity.CENTER
            visibility = if (prefs.getBoolean("orig", false)) android.view.View.VISIBLE
                         else android.view.View.GONE
        }
        val trans = TextView(this).apply {
            setTextColor(Config.colors[prefs.getInt("color", 0)].second)
            textSize = size; gravity = Gravity.CENTER
        }
        val stop = TextView(this).apply {
            text = "✕ Detener"; setTextColor(Color.LTGRAY); textSize = 12f
            gravity = Gravity.END; setPadding(0, (4 * dp).toInt(), 0, 0)
            setOnClickListener { stopSelf() }
        }
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(prefs.getInt("alpha", 190), 0, 0, 0))
            setPadding(pad, pad, pad, pad)
            addView(orig); addView(trans); addView(stop)
        }
        val screenH = resources.displayMetrics.heightPixels
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP
            y = when (prefs.getInt("pos", 2)) {
                0 -> (100 * dp).toInt()
                1 -> screenH / 2 - (60 * dp).toInt()
                else -> screenH - (280 * dp).toInt()
            }
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        var startY = 0
        var touchY = 0f
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startY = lp.y; touchY = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(b, lp)
                }
            }
            true
        }
        wm.addView(b, lp)
        box = b; tvOrig = orig; tvTrans = trans
    }

    private fun show(text: String) {
        main.post { tvTrans?.text = text; scheduleClear() }
    }

    private fun scheduleClear() {
        main.removeCallbacks(clearRunnable)
        main.postDelayed(clearRunnable, 5000)
    }

    private fun update(orig: String, doTranslate: Boolean) {
        main.post { tvOrig?.text = orig; scheduleClear() }
        if (doTranslate) {
            translator?.translate(orig)?.addOnSuccessListener {
                tvTrans?.text = it; scheduleClear()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startCapture() {
        val proj = projection ?: return
        val config = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(maxOf(minBuf, 8000) * 2)
            .setAudioPlaybackCaptureConfig(config)
            .build()
        record = rec
        rec.startRecording()
        running = true

        worker = Thread {
            val buf = ShortArray(4000)
            var lastPartial = ""
            var lastTranslated = 0L
            val rcg = recognizer ?: return@Thread
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (rcg.acceptWaveForm(buf, n)) {
                    // Frase completa: la traducción más exacta
                    val t = JSONObject(rcg.result).optString("text")
                    if (t.isNotBlank()) update(t, true)
                } else {
                    val p = JSONObject(rcg.partialResult).optString("partial")
                    if (p.isNotBlank() && p != lastPartial) {
                        lastPartial = p
                        val now = System.currentTimeMillis()
                        // Parciales: solo si ya hay contexto suficiente y no más de 1 cada 1,5 s
                        val go = now - lastTranslated > 1500 && p.split(" ").size >= 5
                        if (go) lastTranslated = now
                        update(p, go)
                    }
                }
            }
        }.also { it.start() }
    }

    override fun onDestroy() {
        destroyed = true
        running = false
        worker?.join(500)
        record?.run { runCatching { stop() }; release() }
        recognizer?.close()
        model?.close()
        translator?.close()
        projection?.stop()
        main.removeCallbacksAndMessages(null)
        box?.let { runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } }
        super.onDestroy()
    }
}
