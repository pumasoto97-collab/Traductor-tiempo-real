package com.example.livetranslate

import android.content.Context
import android.graphics.Color

object Config {
    // Idiomas de origen (los que Vosk puede reconocer)
    val sources = listOf(
        "en" to "Inglés", "es" to "Español", "fr" to "Francés", "de" to "Alemán",
        "it" to "Italiano", "pt" to "Portugués", "ru" to "Ruso"
    )
    // Idiomas de destino (ML Kit)
    val targets = sources + listOf(
        "ja" to "Japonés", "zh" to "Chino", "ko" to "Coreano", "ar" to "Árabe", "hi" to "Hindi"
    )
    // Modelos pequeños de Vosk, se descargan desde la app la primera vez
    val models = mapOf(
        "en" to "vosk-model-small-en-us-0.15", "es" to "vosk-model-small-es-0.42",
        "fr" to "vosk-model-small-fr-0.22", "de" to "vosk-model-small-de-0.15",
        "it" to "vosk-model-small-it-0.22", "pt" to "vosk-model-small-pt-0.3",
        "ru" to "vosk-model-small-ru-0.22"
    )
    val colors = listOf(
        "Blanco" to Color.WHITE, "Amarillo" to 0xFFFFEB3B.toInt(),
        "Verde" to 0xFF69F0AE.toInt(), "Cian" to 0xFF18FFFF.toInt()
    )
    val positions = listOf("Arriba", "Centro", "Abajo")

    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
}
