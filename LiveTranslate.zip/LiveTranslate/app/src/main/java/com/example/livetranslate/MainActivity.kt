package com.example.livetranslate

import android.Manifest
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var preview: TextView
    private val prefs by lazy { Config.prefs(this) }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r[Manifest.permission.RECORD_AUDIO] == true) downloadTranslationModel()
            else status.text = "Necesito el permiso de micrófono para capturar el audio."
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptionService::class.java)
                    .putExtra(CaptionService.EXTRA_CODE, r.resultCode)
                    .putExtra(CaptionService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                status.text = "Subtítulos activos. Abre tu vídeo. (La primera vez con un idioma nuevo se descarga su modelo de voz.)"
            } else status.text = "Captura de audio cancelada."
        }

    private fun col(id: Int) = ContextCompat.getColor(this, id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(top: Int = 0) =
        LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun rounded(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != null) setStroke(dp(2), stroke)
    }

    private fun card(title: String, vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(col(R.color.card), 20)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        addView(TextView(context).apply {
            text = title; textSize = 12f; letterSpacing = 0.1f
            typeface = Typeface.DEFAULT_BOLD; setTextColor(col(R.color.accent))
        })
        views.forEach { addView(it) }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(col(R.color.muted))
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun spinner(items: List<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        background = rounded(col(R.color.field), 12)
        setPadding(dp(8), dp(6), dp(8), dp(6))
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                onSel(pos); preview()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun seek(max: Int, value: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = value
        val tint = ColorStateList.valueOf(col(R.color.accent))
        progressTintList = tint; thumbTintList = tint
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { onChange(p); preview() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun preview() {
        if (!::preview.isInitialized) return
        preview.textSize = prefs.getInt("size", 18).toFloat()
        preview.setTextColor(Config.colors[prefs.getInt("color", 0)].second)
        preview.setBackgroundColor(Color.argb(prefs.getInt("alpha", 190), 0, 0, 0))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        fun idx(list: List<Pair<String, String>>, key: String, def: String) =
            list.indexOfFirst { it.first == prefs.getString(key, def) }.coerceAtLeast(0)

        // Cabecera con icono
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(context).apply {
                setImageResource(R.mipmap.ic_launcher)
                layoutParams = LinearLayout.LayoutParams(dp(60), dp(60))
            })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, 0, 0)
                addView(TextView(context).apply {
                    text = "Subtítulos en vivo"; textSize = 24f
                    typeface = Typeface.DEFAULT_BOLD; setTextColor(col(R.color.text))
                })
                addView(TextView(context).apply {
                    text = "Traduce el audio de tus vídeos"; textSize = 14f
                    setTextColor(col(R.color.muted))
                })
            })
        })

        root.addView(card("IDIOMAS",
            label("Idioma del audio"),
            spinner(Config.sources.map { it.second }, idx(Config.sources, "src", "en")) {
                prefs.edit().putString("src", Config.sources[it].first).apply()
            },
            label("Traducir a"),
            spinner(Config.targets.map { it.second }, idx(Config.targets, "dst", "es")) {
                prefs.edit().putString("dst", Config.targets[it].first).apply()
            }
        ), lp(22))

        root.addView(card("APARIENCIA",
            label("Tamaño de letra"),
            seek(24, prefs.getInt("size", 18) - 12) { prefs.edit().putInt("size", it + 12).apply() },
            label("Opacidad del fondo"),
            seek(255, prefs.getInt("alpha", 190)) { prefs.edit().putInt("alpha", it).apply() },
            label("Color del texto"),
            spinner(Config.colors.map { it.first }, prefs.getInt("color", 0)) {
                prefs.edit().putInt("color", it).apply()
            },
            label("Posición inicial (luego puedes arrastrarlos)"),
            spinner(Config.positions, prefs.getInt("pos", 2)) {
                prefs.edit().putInt("pos", it).apply()
            },
            CheckBox(this).apply {
                text = "Mostrar también el texto original"
                setTextColor(col(R.color.text))
                buttonTintList = ColorStateList.valueOf(col(R.color.accent))
                isChecked = prefs.getBoolean("orig", false)
                setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("orig", c).apply() }
                setPadding(0, dp(10), 0, 0)
            }
        ), lp(14))

        preview = TextView(this).apply {
            text = "Así se verán los subtítulos"
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }
        root.addView(card("VISTA PREVIA", preview.also {
            it.layoutParams = lp(10)
        }), lp(14))
        preview()

        status = TextView(this).apply {
            text = "Listo para empezar."
            setTextColor(col(R.color.muted)); textSize = 14f
            setPadding(dp(4), dp(18), dp(4), dp(10))
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Iniciar subtítulos"; isAllCaps = false; textSize = 16f
            typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(col(R.color.accent), col(R.color.accent2))
            ).apply { cornerRadius = dp(28).toFloat() }
            stateListAnimator = null
            setOnClickListener { startFlow() }
        }, LinearLayout.LayoutParams(MATCH_PARENT, dp(56)))

        root.addView(Button(this).apply {
            text = "Detener"; isAllCaps = false; textSize = 16f
            setTextColor(col(R.color.text))
            background = rounded(Color.TRANSPARENT, 28, col(R.color.muted))
            stateListAnimator = null
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptionService::class.java))
                status.text = "Detenido."
            }
        }, LinearLayout.LayoutParams(MATCH_PARENT, dp(56)).apply { topMargin = dp(10) })

        val scroll = ScrollView(this).apply { addView(root) }
        // Respeta barras del sistema (Android 15 dibuja de borde a borde)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(scroll)
    }

    private fun startFlow() {
        if (prefs.getString("src", "en") == prefs.getString("dst", "es")) {
            status.text = "El idioma de origen y el de destino deben ser distintos."
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Concede el permiso de superposición y vuelve a pulsar Iniciar."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(perms.toTypedArray())
    }

    private fun downloadTranslationModel() {
        status.text = "Descargando modelo de traducción (solo la primera vez por idioma)..."
        val translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(prefs.getString("src", "en")!!)
                .setTargetLanguage(prefs.getString("dst", "es")!!)
                .build()
        )
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                translator.close()
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
            .addOnFailureListener {
                translator.close()
                status.text = "Error al descargar el modelo: ${it.message}"
            }
    }
}
