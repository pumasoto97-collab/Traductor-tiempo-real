package com.example.livetranslate

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object ModelStore {
    /** Devuelve la carpeta del modelo de voz, descargándolo si hace falta. */
    fun ensure(ctx: Context, lang: String, progress: (Int) -> Unit): File {
        val name = Config.models.getValue(lang)
        val root = File(ctx.filesDir, "models").apply { mkdirs() }
        val dir = File(root, name)
        if (File(dir, ".ok").exists()) return dir

        val zip = File(ctx.cacheDir, "$name.zip")
        val conn = URL("https://alphacephei.com/vosk/models/$name.zip")
            .openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        val total = conn.contentLength.toLong()
        conn.inputStream.use { input ->
            zip.outputStream().use { out ->
                val buf = ByteArray(32768)
                var done = 0L
                var last = -1
                while (true) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val p = (done * 100 / total).toInt()
                        if (p != last) { last = p; progress(p) }
                    }
                }
            }
        }
        ZipInputStream(zip.inputStream()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val out = File(root, e.name)
                if (!out.canonicalPath.startsWith(root.canonicalPath + File.separator))
                    throw SecurityException("Ruta no válida en el zip")
                if (e.isDirectory) out.mkdirs()
                else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zin.copyTo(it) }
                }
                e = zin.nextEntry
            }
        }
        zip.delete()
        File(dir, ".ok").writeText("ok")
        return dir
    }
}
